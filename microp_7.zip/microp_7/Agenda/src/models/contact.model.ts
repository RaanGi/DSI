export interface Contact {

    key?: string;//manejará el id cuando se utiliza firebase
    
    nombre: string;
    
    organizacion: string;
    
    movil: string;
    
    correo: string;
}