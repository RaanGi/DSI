export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyATP9ZoofrFr0QyBC3zfraSklbbxQMIVT0",
    authDomain: "microp7-6f687.firebaseapp.com",
    databaseURL: "https://microp7-6f687.firebaseio.com",
    projectId: "microp7-6f687",
    storageBucket: "microp7-6f687.appspot.com",
    messagingSenderId: "851866520410"
};